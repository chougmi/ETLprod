# pentaho_cnss_file_management
You can find here pentaho files to manage cnss files.
